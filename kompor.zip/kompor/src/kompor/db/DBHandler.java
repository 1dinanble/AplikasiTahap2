
package kompor.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.swing.JOptionPane;
import kompor.model.Kompor;
import kompor.model.KomporProperty;

public class DBHandler {
    public final Connection conn;
    
    public DBHandler(String driver) {
        this.conn = DBHelper.getConnection(driver);
    }
    public void addKompor(Kompor kom){
        String insertkom = "INSERT INTO `kompor`(`nama`, `harga`, `tanggalBeli`,`tipe`,`merk`)"
                + "VALUES (?,?,?,?,?)";
        try {
            PreparedStatement stmtInsert = conn.prepareStatement(insertkom);
            stmtInsert.setString(1, kom.getNama());
            stmtInsert.setString(2, kom.getHarga());
            stmtInsert.setString(3, kom.getTanggalBeli());
            stmtInsert.setString(4, kom.getTipe());
            stmtInsert.setString(5, kom.getMerk());
            stmtInsert.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ObservableList<KomporProperty> getKompor(){
        ObservableList<KomporProperty> data = FXCollections.observableArrayList();
        
        String sql = "SELECT nama, harga, tanggalBeli, tipe, merk FROM `kompor` ORDER BY nama";
        
        try {
            ResultSet rs = conn.createStatement().executeQuery(sql);
            while (rs.next()){
                KomporProperty kom = new KomporProperty(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
                data.add(kom);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return data;
    }
    public void deleteKompor(KomporProperty kom){
        String deletekom = "DELETE FROM kompor WHERE `kompor`.`nama` = ?";
        try {
            PreparedStatement stmtDelete = conn.prepareStatement(deletekom);
            stmtDelete.setString(1, kom.getNama());
            stmtDelete.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void editKompor(KomporProperty kom){
        try {
            String kompor = "UPDATE kom SET nama = '"+kom.getNama()+"', harga = '"+kom.getHarga()+"',TanggalBeli = '"+kom.getTanggalBeli()+"',tipe = '"+kom.getTipe()+"',merk = '"+kom.getMerk()+"' WHERE nama = '"+kom.getNama()+"'";
            java.sql.Connection conn=(Connection)config.configDB();
            java.sql.PreparedStatement pst=conn.prepareStatement("MYSQL");
            pst.execute();
            JOptionPane.showMessageDialog(null, "data berhasil di edit");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Perubahan Data Gagal"+e.getMessage());
        }
        load_table();
        kosong();
    } 
       
}
