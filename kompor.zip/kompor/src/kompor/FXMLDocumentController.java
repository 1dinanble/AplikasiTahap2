
package kompor;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import kompor.db.DBHandler;
import kompor.model.Kompor;


public class FXMLDocumentController implements Initializable {

    @FXML
    private Button btnSave;

    @FXML
    private DatePicker dpTanggalBeli;

    @FXML
    private ToggleGroup tipe;

    @FXML
    private Label label;

    @FXML
    private RadioButton rdGas;

    @FXML
    private RadioButton rdListrik;

    @FXML
    private TextField tfKompor;

    @FXML
    private TextField tfNama;
    
    @FXML
    private TextField tfHarga;

    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        System.out.println(tfNama.getText());
        System.out.println(tfHarga.getText());
        System.out.println(dpTanggalBeli.getValue().toString());
        String tipe="";
        if (rdGas.isSelected())
           tipe=rdGas.getText();
        if (rdListrik.isSelected())
           tipe=rdListrik.getText();
        System.out.println(tipe);
        System.out.println(tfKompor.getText());
//        Mahasiswa(String npm, String nama, String tanggalLahir, String gender, String kompor)
        Kompor kom = new Kompor(tfNama.getText(),tfHarga.getText(),dpTanggalBeli.getValue().toString(),
            tipe,tfKompor.getText());
        DBHandler dh = new DBHandler("MYSQL");
        dh.addKompor(kom);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
