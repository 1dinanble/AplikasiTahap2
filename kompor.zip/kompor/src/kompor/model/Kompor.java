
package kompor.model;


public class Kompor {
    private String nama;
    private String harga;
    private String tanggalBeli;
    private String tipe;
    private String merk;
    
    public Kompor(String nama, String harga, String tanggalBeli, String tipe, String merk) {
        this.nama = nama;
        this.harga = harga;
        this.tanggalBeli = tanggalBeli;
        this.tipe = tipe;
        this.merk = merk;
    }

    
    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getTanggalBeli() {
        return tanggalBeli;
    }

    public void setTanggalBeli(String tanggalBeli) {
        this.tanggalBeli = tanggalBeli;
    }

    public String getTipe() {
        return tipe;
    }

    public void setTipe(String tipe) {
        this.tipe = tipe;
    }

    public String getMerk() {
        return merk;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }
    

 
    
    
}
