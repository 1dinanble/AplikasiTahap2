
package kompor.model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class KomporProperty {
    private StringProperty nama;
    private StringProperty harga;
    private StringProperty tanggalBeli;
    private StringProperty tipe;
    private StringProperty merk;
    
    public KomporProperty(String nama, String harga, String tanggalBeli, String tipe, String merk) {
        this.nama = new SimpleStringProperty(nama);
        this.harga = new SimpleStringProperty(harga);
        this.tanggalBeli = new SimpleStringProperty(tanggalBeli);
        this.tipe = new SimpleStringProperty(tipe);
        this.merk = new SimpleStringProperty(merk);
    }
    public KomporProperty(Kompor kom){
        this.nama = new SimpleStringProperty(kom.getNama());
        this.harga = new SimpleStringProperty(kom.getHarga());
        this.tanggalBeli = new SimpleStringProperty(kom.getTanggalBeli());
        this.tipe = new SimpleStringProperty(kom.getTipe());
        this.merk = new SimpleStringProperty(kom.getMerk());
    }
    public StringProperty getNamaProperty() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = new SimpleStringProperty(nama);
    }

    public StringProperty getHargaProperty() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = new SimpleStringProperty(harga);
    }

    public StringProperty getTanggalBeliProperty() {
        return tanggalBeli;
    }

    public void setTanggalBeli(String tanggalbeli) {
        this.tanggalBeli = new SimpleStringProperty(tanggalbeli);
    }

    public StringProperty getTipeProperty() {
        return tipe;
    }

    public void setTipe(String tipe) {
        this.tipe = new SimpleStringProperty(tipe);
    }

    public StringProperty getMerkProperty() {
        return merk;
    }

    public void setMerk(String merk) {
        this.merk = new SimpleStringProperty(merk);
    }

    public String getNama() {
        return nama.get();
    }

    public String getHarga() {
        return harga.get();
    }

    public String getTanggalBeli() {
        return tanggalBeli.get();
    }

    public String getTipe() {
        return tipe.get();
    }

    public String getMerk() {
        return merk.get();
    }
    
}
