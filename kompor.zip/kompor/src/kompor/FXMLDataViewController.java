package kompor;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import kompor.db.DBHandler;
import kompor.model.KomporProperty;


public class FXMLDataViewController implements Initializable {
    
    @FXML
    private TableView<KomporProperty> tblKompor;

    @FXML
    private TableColumn<KomporProperty, String> colTipe;

    @FXML
    private TableColumn<KomporProperty, String> colNama;

    @FXML
    private TableColumn<KomporProperty, String> colHarga;

    @FXML
    private TableColumn<KomporProperty, String> colMerk;

    @FXML
    private TableColumn<KomporProperty, String> colTglBeli;

    @FXML
    private MenuItem menuAddData;

    @FXML
    private MenuItem menuDeleteData;
    
    @FXML
    private MenuItem menuEditData;
    
    @FXML
    void viewAddDataForm(ActionEvent event) throws IOException {
        Stage modal = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        Scene scene = new Scene(root);
        modal.setScene(scene);
//        modal.initOwner(((Node)event.getSource()).getScene().getWindow() );
        modal.initModality(Modality.APPLICATION_MODAL);
        modal.showAndWait();
    }
    
    @FXML
    void deleteDataKompor(ActionEvent event) {
        KomporProperty kom = tblKompor.getSelectionModel().getSelectedItem();
        int ans = JOptionPane.showConfirmDialog(null, "Yakin Akan Menghapus?");
        if (ans == JOptionPane.YES_OPTION) {
            DBHandler dh = new DBHandler("MYSQL");
            dh.deleteKompor(kom);
            showDataKompor();
        }

    }
    
    @FXML
    void editDataKompor(ActionEvent event) {
        KomporProperty kom = tblKompor.getSelectionModel().getSelectedItem();
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        showDataKompor();
        tblKompor.getSelectionModel().selectedIndexProperty().addListener(evt -> {
//            JOptionPane.showMessageDialog(null,"Test Klik");
            menuDeleteData.setDisable(false);
            menuEditData.setDisable(false);
        });
    }
    
    public void showDataKompor() {
        DBHandler dh = new DBHandler("MYSQL");
        ObservableList<KomporProperty> data = dh.getKompor();
        colTipe.setCellValueFactory(new PropertyValueFactory<>("tipe"));
        colNama.setCellValueFactory(new PropertyValueFactory<>("nama"));
        colHarga.setCellValueFactory(new PropertyValueFactory<>("harga"));
        colMerk.setCellValueFactory(new PropertyValueFactory<>("merk"));
        colTglBeli.setCellValueFactory(new PropertyValueFactory<>("tanggalBeli"));
        tblKompor.setItems(null);
        tblKompor.setItems(data);
    }
    
}
